# 💰 MeuToken (MTK) - Criptomoeda do Curso Blockchain DIO

Este projeto é parte da formação Blockchain da DIO. Criamos aqui uma criptomoeda ERC-20 chamada **MeuToken (MTK)** usando Solidity e a biblioteca OpenZeppelin.

## 📄 Descrição

O contrato `MeuToken.sol` representa um token ERC-20 padrão com as seguintes características:

- Nome: MeuToken
- Símbolo: MTK
- Total inicial: 1000 tokens (mintados para o criador do contrato)

## 🛠️ Tecnologias

- Solidity ^0.8.0
- OpenZeppelin Contracts
- Hardhat (opcional para testes e deploy)

## ▶️ Como rodar

1. Clone o repositório:
   ```bash
   git clone https://github.com/seuusuario/dio-blockchain-moeda-curso.git
   cd dio-blockchain-moeda-curso
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Compile o contrato:
   ```bash
   npx hardhat compile
   ```

4. (Opcional) Faça deploy em uma testnet como Goerli usando sua carteira Metamask + Infura/Alchemy.

## 📄 Licença

MIT

---

🧑‍💻 Criado por [Seu Nome] como parte da formação em Blockchain da [DIO](https://dio.me)
